public class App {
    public static void main(String[] args) throws Exception {

        CaixaEletronico caixa = new CaixaEletronico();
        caixa.executar();

        //Cliente cliente = new Cliente("João", "123.456.789-00");
        //JOptionPane.showMessageDialog(null, cliente.toString());
    }
}
