
/**
 * Classe criada para facilitar a execucao do Jogo
 * 
 * @author Julio César Alves
 * @version 2022-05-31
 */
public class JogoNave
{
    public static void main(String[] args)
    {
		Cenario cenario;
		
        cenario = new Cenario();
        
        cenario.executarLoopDeJogo();
    }
}
