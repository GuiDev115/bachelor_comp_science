## Projeto 1.4 dos Slides

Projeto de carro para PPOO

## Estrutura do respositório

Contém nesse repositório:

- `src`: diretório com os principais recursos
- `lib`: diretório com as dependencias

Após compilado terá o diretório /bin.

> Se caso queira, pode mudar a estrutura abrindo: `.vscode/settings.json` e atualizar as configuraçes
