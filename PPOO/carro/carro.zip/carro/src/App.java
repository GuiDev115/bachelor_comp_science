import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {
        ExibirTela exibirTela = new ExibirTela();
        exibirTela.executar();
    }
}